package com.example.to_do_list;

import android.app.Application;
import androidx.lifecycle.LiveData;

import com.example.to_do_list.dao.TaskDao;

import java.util.List;
public class TaskRepository {
    private final TaskDao taskDao;
    private final LiveData<List<Task>> allTasks;
    public TaskRepository(Application application){
        AppDatabase db = AppDatabase.getDatabase(application);
        taskDao = db.taskDao();
        allTasks = taskDao.getALLTasks();
    }

    public LiveData<List<Task>> getAllTasks() {
        return allTasks;
    }

    public void insert(Task task){
        AppDatabase.databaseWriteExecutor.execute(()->taskDao.insert(task));

    }

    public void delete(Task task){
        AppDatabase.databaseWriteExecutor.execute(()->taskDao.delete(task));
    }

    public void update(Task task){
        AppDatabase.databaseWriteExecutor.execute(()->taskDao.update(task));
    }
}
