package com.example.to_do_list;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.to_do_list.dao.ReminderReceiver;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements TaskAdapter.OnTaskClickListener {

     EditText editTextTask;
     Button buttonAdd;
     RecyclerView recyclerViewTasks;
     ArrayList<String> taskList;
     TaskAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        editTextTask = findViewById(R.id.editTextTask);
        buttonAdd = findViewById(R.id.buttonAdd);
        recyclerViewTasks = findViewById(R.id.RecyclerViewTasks);

        // Set up RecyclerView
        recyclerViewTasks.setLayoutManager(new LinearLayoutManager(this));
        adapter = new TaskAdapter(new ArrayList<>());
        recyclerViewTasks.setAdapter(adapter);

        //initialize viewmodel
        TaskViewModel taskViewModel = new ViewModelProvider(this).get(TaskViewModel.class);
        taskViewModel.getAllTasks().observe(this, tasks -> {
           adapter.setTasks(tasks);
        });
        //notifications
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    "task_channel",
                    "Task Reminders",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Notifies users about pending tasks");

            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }


        // Add task button click listener
        buttonAdd.setOnClickListener(v -> {
            String task = editTextTask.getText().toString().trim();
            if (!task.isEmpty()) {
                Task newtask = new Task();
                newtask.taskText = "taskText";
                newtask.isCompleted = false;
                newtask.deadline = 0;
                taskViewModel.insert(newtask);
                editTextTask.setText("");
            }
        });
    }
    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void onTaskClick(Task task){
        taskList.remove(task);
        adapter.notifyDataSetChanged();
    }

    AlarmManager alarmManager;

    private void scheduleTaskReminder(int taskId, long taskTime) {

        alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

        Intent intent = new Intent(this, ReminderReceiver.class);
        intent.putExtra("TASK_ID", taskId);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, taskId, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        //  Schedule a reminder 1 minute from now
        long reminderTime = System.currentTimeMillis() + 60000; // 1 minute in milliseconds
        scheduleTaskReminder(taskId, reminderTime);

        alarmManager.set(AlarmManager.RTC_WAKEUP, taskTime, pendingIntent);
    }


}