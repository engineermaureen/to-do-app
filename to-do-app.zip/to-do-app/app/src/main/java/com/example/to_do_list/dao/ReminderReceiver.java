package com.example.to_do_list.dao;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent){
        String taskText = intent.getStringExtra("taskText");
        String taskTime = intent.getStringExtra("taskTime");
    }
}
