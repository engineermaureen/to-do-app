package com.example.to_do_list;

import android.app.Notification;

public class NotificationManager {
    public static final int IMPORTANCE_HIGH = 1;

    public void notify(int i, Notification build) {
    }
}
